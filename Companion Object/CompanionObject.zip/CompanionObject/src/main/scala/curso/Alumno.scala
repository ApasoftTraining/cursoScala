package curso

//Creacion de la clase
//Object Companion
class Estudiante(var nombre:String, var apellidos :String, var tipo: String)
{
  override def toString: String = "Nombre:"+nombre+" "+apellidos+" "+tipo
}

//Creacion del companion Object

object Estudiante{
  val TIPO_VIP="VIP"
  val TIPO_NORMAL="NORMAL"
  def estatico ={
      println("Esto es un metodo estatico")
  }
}


//Main
object Principal{
  def main(args: Array[String]): Unit = {
      var estudiante1=new Estudiante("Alberto","Perez",tipo=Estudiante.TIPO_VIP)
      Estudiante.estatico
      println(estudiante1)
  }
}