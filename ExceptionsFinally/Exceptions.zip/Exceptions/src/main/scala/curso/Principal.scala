package curso

object Principal {
  def dividir (n1:Int,n2:Int):Float= {
        n1/n2
    }

    def main(args: Array[String]): Unit = {
      try {
        //println(dividir(10, 0))
        //val array1=Array(1,5,7)
        //array1(90)
      }catch {
        case ex: ArithmeticException => println("Se ha producido la excecpion:"+ex)
        case ex1: Throwable => println("Se ha producido la excepcion:"+ex1)
      }
      finally {
         println("Este trozo de codigo siempre se ejecuta")
      }
    }
}