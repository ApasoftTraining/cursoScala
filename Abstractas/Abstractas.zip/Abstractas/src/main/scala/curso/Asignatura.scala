package curso

abstract class Persona(nombre:String,apellidos:String)
{
  def mayusculas: Unit = {
     println(nombre.toUpperCase)
  }
  
  def nombreCompleto:String
}

class Estudiante (nombre:String,apellidos:String) extends Persona (nombre,apellidos){
  override def nombreCompleto: String = nombre+" "+apellidos
}

object Principal{
  def main(args: Array[String]): Unit = {
      var estudiante1=new Estudiante("alberto","perez")
      println(estudiante1.nombreCompleto)
      println(estudiante1.mayusculas)

      var estudiante2=new Persona("Raul","Rodriguez") {
            override def nombreCompleto: String = "hola"
      }
      println(estudiante2.nombreCompleto)
  }
}

